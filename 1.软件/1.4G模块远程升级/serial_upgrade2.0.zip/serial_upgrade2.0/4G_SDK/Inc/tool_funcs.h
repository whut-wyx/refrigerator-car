#ifndef __TOOL_FUNCS_H
#define __TOOL_FUNCS_H
#include "userConfig.h"
#include <stdint.h>

 

/* SDK工作状态结构体 */
typedef struct 
{
	unsigned char bootUpload_succeed;                 //开机上传属性参数成功
	unsigned char waitting_receipt;                   //等待回执消息中
	unsigned char signalIntensity;                    //4G模块信号强度
	unsigned char pp_modified;                        //属性参数被修改
}CC_PM_Status;                                        //SDK工作状态结构体
  
                                                    //实时数据结构体
extern CC_PM_Status ccpm_status;                    //SDK工作状态结构体变量
 

                                                                //清空串口消息数组
uint8_t my_strstr(uint8_t *str1, unsigned int str1_len, char *str2, unsigned int str2_len);     //在给定字符串中查找给定子字符串
int base64_decode(const char *indata, uint32_t inlen, char *outdata, uint32_t *outlen);
int num_strchr(const char *str, char c);
#endif

