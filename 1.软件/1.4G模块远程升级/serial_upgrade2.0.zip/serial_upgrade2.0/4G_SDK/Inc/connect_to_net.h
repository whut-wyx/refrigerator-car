#ifndef __CONNECT_TO_NET_H
#define __CONNECT_TO_NET_H
#include <stdint.h>
#include <stdlib.h>
#include "usart.h"
typedef enum
{
  DISABLEPRI=0X00U,
  ENABLEPRI=0X01U,
}enumPrint;

typedef enum
{
		GSM_STATE_INIT = 0x00u,
    GSM_STATE_PWR,
    GSM_STATE_AT,

    GSM_CGATT_CHECK,
	  GSM_CIPMODE_CHECK,
    GSM_CSTT,
		GSM_SAPBR,
		GSM_CIICR,
		GSM_CIFSR,
		GSM_CIPSTATUS,
    
    GSM_HTTPINIT,
    GSM_HTTPPARA_URL,
    GSM_HTTPPARA_USER,
    GSM_HTTPDATA,
    GSM_Sign_up,
    GSM_HTTPACTION,
    GSM_HTTPREAD,
    GSM_HTTPTERM,
		
    GSM_MCONFIG,
    GSM_SSLMIPSTART,
    GSM_MCONNECT,
		GSM_MSUB,
		GSM_MSUB1,
		GSM_MQTTMSGSET,
		GSM_CONNECT,
		GSM_MPUB0,
		GSM_MPUB1,
		
    GSM_OVER,
    GSM_MQTT_PUBLIC_REQHEART,//请求心跳数据
    GSM_MQTT_PUBLIC_DATA,//温度数据
    GSM_MQTT_PUBLIC_CURRENT,//电流数据
    GSM_MQTT_PUBLIC_STATE,//当前状态数据
    GSM_MQTT_PUBLIC_WARN,//告警数据
    GSM_MQTT_PUBLIC_HEART,//心跳数据
    
		GSM_MQTT_WAITSMG,
    GSM_STATE_MAX,
}GSM_State;

typedef enum 
{
  BackState_INIT  =  0x00u,
	BackState_OK    =   0x01u,
  BackState_ERR   =   0x02u,
}Analysis_BackState;

typedef struct
{
    int32_t signalval;
    char CCID[21];
		char IEMI[16];
    char IPAddr[17];
    char TIME[20];
}GSM_GetVal;

typedef struct
{
    GSM_State u8AtState;//Air724UG的AT指令集
    Analysis_BackState u8AnalyState;
    GSM_GetVal gsGetGsmVal;
}GSM_Config;

extern GSM_Config gsm_control;


void Net_StateHandle(void);                              //连接到云
uint8_t mystrstr(char *str,enumPrint pristate);	

void Json_analysis(void);

typedef struct 
{
	uint32_t Index_int;
	char* Code_Str;
}JSON_Config_t;

extern uint8_t update_flag;
extern uint8_t mpub_flag;

extern uint8_t file_bin[FILE_LEN];
extern uint32_t appsize;
extern uint32_t usart2_cnt;
void update_pack(uint8_t pos, char* str);
void Recv_bin(void);

#endif

