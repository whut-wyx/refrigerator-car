#ifndef __DATA_TO_STORED_H
#define __DATA_TO_STORED_H
#include "tool_funcs.h"


typedef struct
{
	int checkout;                                                   //校验位
	int connect_mode;                                               //连云模式 0X01表示一型一密方式,0X02表示一机一密方式
  char hash_value[40];                                            //哈希值
	char ProductKey[16];
	char ProductSecret[20];
	char DeviceName[20];
	char DeviceSecret[40];
}SignIn; 
																																		//四元组结构体
extern SignIn SignIn_info;                                    //设备四元组

void Update_Flash(void);                           
void DataFlash_init(void); 
void Q_factory_setting(void);
//void pp2page0(void);                                                  //将属性参数结构体变量propertyParameters的值存入page0
#endif // !__DATA_TO_STORED_H

