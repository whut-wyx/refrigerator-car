#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <jansson.h>
#include "connect_to_net.h"
#include "tool_funcs.h"
#include "data_to_Stored.h"
#include "md5.h"
#include "netWork.h"
#include "usart.h"
#include "malloc.h"

GSM_Config gsm_control = {GSM_STATE_AT};//��һ������ΪGSM_STATE_AT
JSON_Config_t json_struct;

uint8_t file_bin[FILE_LEN] __attribute__ ((at(0X20001000))) = {0};
uint8_t update_flag = 0;
uint8_t mpub_flag = 0;
uint32_t usart2_cnt = 0;

bool waitsmg_flag = false;
bool recvlast_flag = false;

static uint8_t errcnt;  
static uint8_t index;
void Net_StateHandle(void)
{
	
	switch(gsm_control.u8AtState)
  	{
    	case GSM_STATE_PWR:
    	{
      		gsm_control.u8AtState = GSM_STATE_AT;
      		break;
    	}
    	case GSM_STATE_AT:
    	{
     	 	printf("GSM_STATE_AT:");
				u2_printf("AT\r\n");

      		if(mystrstr("OK",DISABLEPRI) == 1)
						
			{
        		errcnt=0;
        		printf("pass.\n");
        		gsm_control.u8AtState=GSM_CGATT_CHECK;
     		}
			else
			{
				errcnt++;
				printf("fail+%u\n",errcnt);
				if(errcnt>=10)
				{
					gsm_control.u8AtState=GSM_STATE_PWR;
					errcnt=0;
				}
			}
      		break;
    	}			
		
		case GSM_CGATT_CHECK:
		{
			printf("GSM_CGATT_CHECK:");
			u2_printf("AT+CGATT?\r\n");
			if(mystrstr("+CGATT: 1\r\n\r\nOK",DISABLEPRI)==1)//41 54 2B 43 47 41 54 54 3D 31 0D 0A 0D 0A 4F 4B 0D 0A
			{
				errcnt=0;
				printf("pass.\n");
				gsm_control.u8AtState=GSM_CIICR;
			}
			else
			{
				errcnt++;
				printf("fail+%u net\n",errcnt);
				if(errcnt>=10)
				{
					gsm_control.u8AtState=GSM_STATE_PWR;
					errcnt=0;
				}
			}
			break;
		}
				
		case GSM_CSTT: //�������磬����apn
		{
			printf("GSM_CSTT:");
			u2_printf("AT+CSTT?\r\n");
			if(mystrstr("OK\r\n",DISABLEPRI)==1)//41 54 2B 43 47 41 54 54 3D 31 0D 0A 0D 0A 4F 4B 0D 0A
			{
				errcnt=0;
				printf("pass.\n");
				gsm_control.u8AtState=GSM_CIICR;
			}
			else
			{
				errcnt++;
				printf("fail+%u net\n",errcnt);
				if(errcnt>=10)
				{
					gsm_control.u8AtState=GSM_STATE_PWR;
					errcnt=0;
				}
			}
			break;
		}
		case GSM_CIICR:
		{
			printf("AT+CIICR:");
			u2_printf("AT+CIICR\r\n");//�����ƶ���������ȡIP��ַ
			if(mystrstr("OK\r\n", DISABLEPRI)==1)
			{
				errcnt=0;
				printf("pass.\n");
				gsm_control.u8AtState=GSM_CIFSR;
			}
			else
			{
				errcnt++;
				printf("fail+%u\n",errcnt);
				if(errcnt>=10)
				{
					gsm_control.u8AtState=GSM_STATE_PWR;
					errcnt=0;
				}
			}
			break;
		}	
	
		case GSM_CIFSR:
		{
			printf("GSM_CIFSR:");
			u2_printf("AT+CIFSR\r\n");//���������CMIOT
			if(mystrstr("AT+CIFSR",DISABLEPRI)==1)
			{
				errcnt=0;
				printf("pass.\n");
				gsm_control.u8AtState=GSM_CIPSTATUS;
			}
			else
			{
				errcnt++;
				printf("fail+%u\n",errcnt);
				if(errcnt>=10)
				{
					gsm_control.u8AtState=GSM_STATE_PWR;
					errcnt=0;
				}
			}
			break;
		}
		case GSM_CIPSTATUS:
		{
			printf("GSM_CIPSTATUS:");
			u2_printf("AT+CIPSTATUS\r\n");//���������CMIOT
			//printf("%s\r\n",usart2_4G);
			if(mystrstr("CONNECT OK",DISABLEPRI)==1)
			{
				errcnt=0;
				printf("pass.\n");
				gsm_control.u8AtState=GSM_MCONFIG;
			}
			else
			{
				errcnt++;
				printf("fail+%u\n",errcnt);
				if(errcnt>=10)
				{
					gsm_control.u8AtState=GSM_STATE_PWR;
					errcnt=0;
				}
			}
			break;
		}
		case GSM_MCONFIG:
		{
			printf("GSM_MCONFIG:");
			u2_printf("AT+MCONFIG=\"wyx\",\"admin\",\"123456\"\r\n");//���������CMIOT
			//printf("%s\r\n",usart2_4G);
			if(mystrstr("OK",DISABLEPRI)==1)
			{
				errcnt=0;
				printf("pass.\n");
				gsm_control.u8AtState=GSM_SSLMIPSTART;
			}
			else
			{
				errcnt++;
				printf("fail+%u\n",errcnt);
				if(errcnt>=10)
				{
					gsm_control.u8AtState=GSM_STATE_PWR;
					errcnt=0;
				}
			}
			break;
		}
		case GSM_SSLMIPSTART:
		{
			printf("GSM_SSLMIPSTART:");
			u2_printf("AT+MIPSTART=\"101.132.26.139\",1883\r\n");//����TCP����
			//printf("%s\r\n",usart2_4G);
			if(mystrstr("CONNECT OK",DISABLEPRI)==1)
			{
				
				errcnt=0;
				printf("pass.\n");							
				gsm_control.u8AtState=GSM_MCONNECT;
			}
			else
			{
				errcnt++;
				printf("fail+%u\n",errcnt);
				if(errcnt>=10)
				{
					gsm_control.u8AtState=GSM_STATE_PWR;
					errcnt=0;
				}
			}
			break;
		}
		case GSM_MCONNECT:
		{
			printf("GSM_MCONNECT:");
			u2_printf("AT+MCONNECT=1,300\r\n");//����TCP����
			if(mystrstr("OK",DISABLEPRI)==1)
			{			
				errcnt=0;
				printf("pass.\n");							
				gsm_control.u8AtState=GSM_MSUB;
			}
			else
			{
				errcnt++;
				printf("fail+%u\n",errcnt);
				if(errcnt>=10)
				{
					gsm_control.u8AtState=GSM_STATE_PWR;
					errcnt=0;
				}
			}
			break;		
		}			
		case GSM_MSUB:
		{
			u2_printf("AT+MSUB=\"bin/0\",0\r\n");//���Ļ���
			if(mystrstr("SUBACK",DISABLEPRI)==1)
			{
				printf("���Ļ���bin/0\r\n");
				errcnt=0;
				printf("pass.\n");
				gsm_control.u8AtState=GSM_MQTTMSGSET;
			}
			else
			{
				errcnt++;
				printf("fail+%u\n",errcnt);
				if(errcnt>=10)
				{
					gsm_control.u8AtState=GSM_STATE_PWR;
					errcnt=0;
				}
			}
			break;
		}	
		case GSM_MQTTMSGSET:
		{
			u2_printf("AT+MQTTMSGSET=0\r\n");
			if(mystrstr("OK",DISABLEPRI)==1)
			{
				errcnt=0;
				printf("pass.\n");
				gsm_control.u8AtState=GSM_MQTT_WAITSMG;
			}
			else
			{
				errcnt++;
				printf("fail+%u\n",errcnt);
				if(errcnt>=10)
				{
					gsm_control.u8AtState=GSM_STATE_PWR;
					errcnt=0;
				}
			}
			break;
		}
		case GSM_MQTT_WAITSMG://�ȴ�������Ϣ
		{
	
			Recv_bin();
			//Json_analysis();
			break;
		}
		default:
		break;
    }
}
/**
  * @brief	���4Gģ�鷵�ص��ַ���
  */	
uint8_t mystrstr(char *str,enumPrint pristate)
{
	uint8_t ret;
	if(pristate)
		printf("%s",usart2_4G);
	
	if(my_strstr(usart2_4G,strlen((char* )usart2_4G),str,strlen(str)) == 1) 	
    	ret = 1;
	else
		ret = 0;		
	memset(usart2_4G,0,RX_LEN_4G);//�������
	return ret;
}

void Json_analysis(void)
{
	if(waitsmg_flag==true)
	{
		char *token=NULL;
		json_error_t err;
		json_t *roott=NULL;
		int bakval=0;
			//char *RAString,*RBString;
			//char *out="todevice/43167344{\"Code\":\"DJ00\",\"Value\":\"0\",\"Index\":13396,\"Time\":15770312}";
			//printf("%s\r\n",GSMData.SaveBuffer);
			
			//p_RecvBuff=out;
			//printf("p_RecvBuff=%s\r\n",p_RecvBuff);
			token=strstr((char*)usart2_4G,"{\"code\"");
			//token=strtok(token,"}");
			//printf("%s\r\n",token);
			
			roott=json_loads(token, JSON_ENCODE_ANY, &err);
		  bakval=json_unpack(roott,"{s:s,s:i}","code",&json_struct.Code_Str,"index",&json_struct.Index_int);
			//printf("bakval=%d\r\n",bakval);
			if(bakval==-1)
			{
				//free(reply);
				//free(p_RecvBuff);
				//free(token);
				memset(usart2_4G,0,sizeof(usart2_4G));
				json_delete(roott);//free
				waitsmg_flag = false;
				return;
			}
				
	
			//printf("stringlen=%d\r\n",stringlen);
			//HAL_UART_Transmit(&huart2,GSMData.SendBuffer,stringlen,0xffff);
			//printf("%s %u",json_struct.Code_Str,json_struct.Index_int);
			update_pack(json_struct.Index_int,json_struct.Code_Str); //��bin�ļ���������ļ���
			//printf("%d\r\n",strlen((char*)json_struct.Code_Str));
			memset(usart2_4G,0,sizeof(usart2_4G));
			//json_delete(roott);//free
			//free(reply);
			//free(p_RecvBuff);
			//free(token);
			//free(roott);
			//printf("ok\r\n");	
			
		//free(reply);
		//free(p_RecvBuff);
		//free(token);
		json_delete(roott);//free
		//waitsmg_flag = false;
	}
}

void update_pack(uint8_t pos, char* str)
{
	if(pos == index)
	{
		//if(rx_len > 1024)//�жϰ���С
		//{
			if(pos == 0)//ȷ�ϵ�һ�����հ��ǵ�0��������λ
			{
				mpub_flag = 1;//�ӻ����ж��ĵ���Ϣ
			}		
	}
		index++;
}
void Recv_bin(void)
{
	if(waitsmg_flag)
	{
		//��������bin/0��Ϣ
		if(usart2_4G[10] == 'b'&&usart2_4G[11] == 'i'&&usart2_4G[12] == 'n'&&usart2_4G[14] == '0')
		{
			int i = 0;
			
			if(rx_len > 1050) //���յ�bin�ļ���
			{
				mpub_flag = 1;
				while(usart2_4G[i++] != ','); //��һ������
				while(usart2_4G[i++] != ','); //�ڶ�������
				//printf("i1:%d\r\n",i);
				//i��Ϊ��һ��bin�ֽڵ�λ��
				//if((usart2_cnt-1 > 0 && usart2_4G[i] != file_bin[usart2_cnt-1])
				while(i < rx_len - 2) //	
				{
					file_bin[usart2_cnt] = usart2_4G[i]; //�ӵ�i����ʼ��ȡ
					usart2_cnt++;
					i++;
				}
				rx_len = 0; //���ظ�����
//				printf("i2:%d\r\n",i);
//				printf("usart_cnt:%d\r\n",usart2_cnt);
			}
			
			if(recvlast_flag)//���һ������
			{
				while(usart2_4G[i++] != ','); //��һ������
				while(usart2_4G[i++] != ','); //�ڶ�������
				//i��Ϊ��һ��bin�ֽڵ�λ��
				while(i < rx_len - 2) //	
				{
					file_bin[usart2_cnt] = usart2_4G[i]; //�ӵ�i����ʼ��ȡ
					usart2_cnt++;
					i++;
				}
				update_flag = 1; //���һ�����ݣ�ˢ�������flash
			}
	 }
	}
}
