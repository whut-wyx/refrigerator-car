/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdbool.h>
#define RX_LEN_4G 2*1024
#define USART3_REC_LEN 120*1024
#define IAP_UPgrade 0
#define FILE_LEN 50*1024
/* USER CODE BEGIN Includes */
void HAL_UART_idleCallback(UART_HandleTypeDef *UartHandle);
/* USER CODE END Includes */

extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart3;
extern DMA_HandleTypeDef hdma_usart2_rx;
/* USER CODE BEGIN Private defines */
extern uint8_t usart2_4G[RX_LEN_4G];
extern uint32_t rx_len; 
extern uint8_t dma2_rx_buffer[RX_LEN_4G];

extern uint8_t USART_RX_BUF[USART3_REC_LEN];
//extern uint8_t usart3_rx_buf[USART3_REC_LEN];
extern uint32_t usart3_cnt;				//���յ��ֽ���	

extern bool waitsmg_flag;
extern bool recvlast_flag;
/* USER CODE END Private defines */

void MX_USART1_UART_Init(void);
void MX_USART2_UART_Init(void);
void MX_USART3_UART_Init(void);

/* USER CODE BEGIN Prototypes */


/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

