/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"
#include <stdio.h>
#include <string.h>
#include "data_to_Stored.h"
#include "connect_to_net.h"
#include "iap.h"
#include "tool_funcs.h"
#include "malloc.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
int fputc(int ch, FILE *f)
{ 	
	while((USART3->SR&0X40)==0);//ѭ������,ֱ���������   
	USART3->DR = (uint8_t) ch;      
	return ch;
}
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void LC_SetGpioStatus(void)
{
	HAL_GPIO_WritePin(ST_PWR_GPIO_Port,ST_PWR_Pin,GPIO_PIN_SET);
	HAL_Delay(1500);
	HAL_GPIO_WritePin(ST_PWR_GPIO_Port,ST_PWR_Pin,GPIO_PIN_RESET);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  __HAL_UART_ENABLE_IT(&huart2,UART_IT_IDLE); //������2�����ж�
  HAL_UART_Receive_DMA(&huart2,dma2_rx_buffer,RX_LEN_4G);
	
	__HAL_UART_ENABLE_IT(&huart2,UART_IT_RXNE); //���������ж�

	__HAL_UART_ENABLE_IT(&huart3,UART_IT_RXNE);		//���������ж�	
	
	
	LC_SetGpioStatus();
	
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {	
#if IAP_UPgrade
		uint32_t oldcnt = 0;
    uint32_t appsize = 0;
    /* USER CODE END WHILE */
		if(usart3_cnt)
		{
			if(oldcnt == usart3_cnt)
			{
				appsize = usart3_cnt;
				oldcnt = 0;
				usart3_cnt = 0;
				printf("�û����������ɣ�\r\n");
				printf("���볤��:%dBytes\r\n",appsize);
			}
			else
				oldcnt = usart3_cnt;
		}
#endif
		
		HAL_GPIO_TogglePin(LED_GPIO_Port,LED_Pin);
		Net_StateHandle();  //�������Ƿ����
		//u2_printf("AT\r\n");	
		HAL_Delay(1000);
		
		if(update_flag)
		{
			//printf("%s\r\n",file_bin);
			printf("usart2_cnt:%d\r\n",usart2_cnt);
			//printf("%x\r\n",(*(volatile uint32_t*)(0X20001000+4)));
			//printf("%x\r\n",(*(volatile uint32_t*)(0X20001000+6144+4)));
			/* �ж��Ƿ�Ϊ0X08XX0XXXX,***.bin�ļ��ĵڶ���4�ֽڼ�¼�ĵ�ַ��Ϣ,***
			���ڽ����������ݴ�0x20001000��ʼ�洢����һ��4���ֽ�Ϊջ����ַ���ڶ���4�ֽ�Ϊ��λ�ж���������ڵ�ַ*/		
			if(((*(volatile uint32_t*)(0X20001000+4))&0xFF000000) == 0x08000000) 		
			{	 
				iap_write_appbin(FLASH_APP_ADDR, file_bin, usart2_cnt);//����FLASH����   
				printf("�̼��������!\r\n");				
				
			}
			else
			{
				printf("error\r\n");
				memset(file_bin,0,usart2_cnt);
				update_flag = 0;
				recvlast_flag = 0;
			}
			if(((*(volatile uint32_t*)(FLASH_APP_ADDR+4))&0xFF000000)==0x08000000)//�ж��Ƿ�Ϊ0X08XXXXXX.
			{	
				printf("��ת���ok\r\n");
				iap_load_app(FLASH_APP_ADDR);//ִ��FLASH APP����
				printf("��ת\r\n");
			}
			else
			{
				printf("%x\r\n",(*(volatile uint32_t*)(FLASH_APP_ADDR+4)));
				printf("ִ��error\r\n");
			}
		}
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

